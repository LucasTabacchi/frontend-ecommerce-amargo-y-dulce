import MiPerfilPage from "./page.client";

export const dynamic = "force-dynamic";

export default function Page() {
  return <MiPerfilPage />;
}
